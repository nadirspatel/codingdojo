import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from './../http.service';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  pet: any;
  petSkills1 = ''
  petSkills2 = ''
  petSkills3 = ''
  errors= [];
  constructor(private _route: ActivatedRoute, private _httpService: HttpService, private _router: Router) { }

  ngOnInit() {
    this.petSkills1 = ''
    this.petSkills2 = ''
    this.petSkills3 = ''
    this.pet = {_id: '', name: "", cuisine: '' }
    this.openEdit()

  }
  openEdit() {
    this._route.params.subscribe((params: Params) => {
      console.log(params['id'])
      let observable = this._httpService.findPets(params['id']);
      observable.subscribe(data => {
        console.log("Got our pet!", data)
        console.log(data['pet'][0].skills[0])
        this.pet = {_id : data['pet'][0]._id, name: data['pet'][0].name, type: data['pet'][0].type, description: data['pet'][0].description, likes: data['pet'][0].likes, skills: data['pet'][0].skills,};
        this.petSkills1 = data['pet'][0].skills[0]
        this.petSkills2 = data['pet'][0].skills[1]
        this.petSkills3 = data['pet'][0].skills[2]
      })
  });
  }
  editPet(id) {
    this.pet.skills[0] = this.petSkills1
    this.pet.skills[1] = this.petSkills2
    this.pet.skills[2] = this.petSkills3
    console.log(this.pet)
    let observable = this._httpService.editPets(id, this.pet);
    observable.subscribe(data => {
      if(data['error']){
        console.log('this is the error', data['error'].message)
        if(data['error'].hasOwnProperty('message')){
          this.errors.push(data['error'].message)
        }else{
          this.errors.push(data['error'])
        }
      }else {
        console.log("Updated!", data)
        this._router.navigate(['pets/' + id]);
      }
    })
  }
}
