import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from './../http.service';
@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
pet: any;
clicked: Boolean;
  constructor(private _route: ActivatedRoute, private _httpService: HttpService, private _router: Router) { }

  ngOnInit() {
    this.clicked = true;
    this.pet = {name: '', type: '', description: '', skills: [], likes: 0};
    this.openEdit()

  }
  openEdit() {
    this._route.params.subscribe((params: Params) => {
      console.log(params['id'])
      let observable = this._httpService.findPets(params['id']);
      observable.subscribe(data => {
        console.log("Got our pet!", data)
        this.pet = {_id : data['pet'][0]._id, name: data['pet'][0].name, type: data['pet'][0].type, description: data['pet'][0].description, skills: data['pet'][0].skills, likes: data['pet'][0].likes};
        console.log(this.pet.comments)
      })
  });
}

delete(id) {
  console.log(id)
  let observable = this._httpService.deletePets(id);
  observable.subscribe(data => {
    console.log("Successfully deleted!", data)
    // this._router.navigate(['']);
  })
}
like(id) {
  this.clicked = false;
  this.pet.likes += 1;
  let observable = this._httpService.editPets(id, this.pet);
  observable.subscribe(data => {
    console.log("Updated!", data)
    // this._router.navigate(['pets/' + id]);
  })
}
}
