import { Component, OnInit } from '@angular/core';
import { HttpService } from './../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  newPet: any;
  errors= [];
  petSkills1 = ''
  petSkills2 = ''
  petSkills3 = ''
  constructor(private _httpService: HttpService, private _router: Router) { }

  ngOnInit() {
    this.petSkills1 = ''
    this.petSkills2 = ''
    this.petSkills3 = ''
    this.newPet= {name: '', type: '', description: '', skills: []}
  }
  createPets() {
    this.newPet.skills.push(this.petSkills1)
    this.newPet.skills.push(this.petSkills2)
    this.newPet.skills.push(this.petSkills3)
    console.log(this.newPet.skills)
    let observable = this._httpService.createPets(this.newPet);
    observable.subscribe(data => {
      console.log(data)
      if(data['error']){
        console.log('this is the error', data['error'].message)
        if(data['error'].hasOwnProperty('message')){
          this.errors.push(data['error'].message)
        }else{
          this.errors.push(data['error'])
        }
      }else {
      console.log("Added Pet!", data)
      this._router.navigate(['/']);
      }
    })
  }
}
