import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) {
    this.getPets();
   }
   getPets(){
    return this._http.get('/get');
  }
  createPets(newProduct) {
    return this._http.post('/create', newProduct)
  }
  newRatings(id, rating) {
    return this._http.post('/rating/'+ id, rating)
  }
  editPets(Id, editPets) {
    return this._http.put('/edit/'+Id, editPets)
  }
  deletePets(Id) {
    return this._http.delete('/delete/'+Id)
  }
  findPets(Id) {
    console.log(Id)
    return this._http.get('/get/'+Id)
  }




}
