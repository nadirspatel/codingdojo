var tasks = require('./../controllers/products.js')
var path = require('path')
module.exports = function(app){
    app.get('/get', tasks.index)
    app.get('/get/:id', tasks.show)
    app.post('/create', tasks.create)
    // app.post('/rating/:id', tasks.newRatings)
    app.put('/edit/:id', tasks.update)
    app.delete('/delete/:id', tasks.delete)
    app.all("*", (req,res,next) => {
        res.sendFile(path.resolve("./public/dist/public/index.html"))
      });
}