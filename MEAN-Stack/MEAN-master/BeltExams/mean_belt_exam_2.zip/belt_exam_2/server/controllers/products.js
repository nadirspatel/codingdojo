const mongoose = require('mongoose'),
    Pet = mongoose.model('Pet')
var double = false;
module.exports = {
    index: function(req, res) {
        Pet.find({}, function(err, pets) {
            if(err){
                res.json({message: 'Error', error: err})
            }else{
            context = {
                'message': 'success',
                'pets': pets
            }
            res.json(context);
            }
        })
    },
    
    create: function(req, res) {
        double = false;
        console.log('this is the request',req.body.name)
        Pet.find({}, function(err, pet) {
            console.log('this is the pet', pet)
            console.log("came through")
            for(let i = 0; i < pet.length; i++){
                if(pet[i].name == req.body.name) {
                    
                    double = true;
                }
            }
            console.log(double)
            if(double == true) {
                res.json({error: 'pet already exists'});
            }
            if(double == false){
            Pet.create(req.body, function(err, result){
                if(err){
                    res.json({message: 'Error', error: err})
                }else{
                    console.log(req.body)
                    res.json({data: result});
                    console.log("worked!!")
                }
            })  
        }
        })
        
    },
    update: function(req, res) {
        console.log("came in here", req.body)
        Pet.update({'_id':req.params.id}, req.body, { upsert: true, runValidators: true }, function(err, result){
            if(err){
                res.json({message: 'Error', error: err})
            }else{
            res.json({data: result});
            }
        })
    },
    delete: function(req, res) {
        Pet.remove({'_id': req.params.id}, function(err, result){
            if(err){
                res.json({message: 'Error', error: err})
            }else{
            res.json({data: result})
            }
        })
    },
    show: function(req, res) {
        Pet.find({"_id":req.params.id}, function(err, pet) {
            if(err){
                res.json({message: 'Error', error: err})
            }else{
            // console.log(users)
            context = {
                'pet': pet
            }
            res.json(context);
        }
        })
    },
    // newRatings: function(req, res) {
    //     Rating.create(req.body, function(err, data){
    //         if(err){
    //              // handle the error from creating a blog
    //         }
    //         else {
    //              Pet.findOneAndUpdate({_id: req.params.id}, {$push: {comments: data}}, function(err, data){
    //                   if(err){
    //                     res.json({message: 'Error', error: err})
    //                   }
    //                   else {
    //                     res.json({data: data});
    //                   }
    //              })
    //          }
    //    })    
    // }
}