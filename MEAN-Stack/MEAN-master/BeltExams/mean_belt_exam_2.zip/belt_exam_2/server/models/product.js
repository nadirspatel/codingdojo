const mongoose = require('mongoose')

var PetSchema = new mongoose.Schema({
    name: {
        type: String,
        minlength: [3, 'Pet must be 3 characters or more'],
        required: [true, 'Name cannot be blank']
    },
    type: {
        type: String,
        minlength: [3, 'type must be 3 characters or more'],
        required: [true, 'Type cannot be blank']
    },
    description: {
        type: String,
        minlength: [3, 'Description must be 3 characters or more'],
        required: [true, "Description cannot be blank"]
    },
    skills: [],
    likes: {
        type: Number,
        default: 0,
        required: [true]
    },
   }, {timestamps: true})

mongoose.model('Pet', PetSchema);