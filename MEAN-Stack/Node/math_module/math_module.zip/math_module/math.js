var mathmodule = require('./mathmodule');
mathmodule.greet();
mathmodule.add(5,6); // add two integers
mathmodule.multiply(5,6); // multiple two integers
mathmodule.square(5); // square of a integer
mathmodule.rand(2,22); // random number between 2 integers
