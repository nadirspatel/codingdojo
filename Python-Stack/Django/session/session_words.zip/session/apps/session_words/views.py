from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime

# Create your views here.

def index(request):
    return render(request,'index.html')

def add_word(request):
    request.session['font_size'] = "12px"
    request.session['color'] = "black"
    request.session['word'] = request.POST['word']
    request.session['color'] = request.POST['color']
    request.session['bigfonts'] = request.POST['bigfonts']
    request.session['time'] = strftime("%Y-%m-%d %H:%M %p", gmtime())
    # is big font enabled?
    if 'bigfonts' in request.POST == 1:
        request.session['font_size'] = "18px"
    else:
        request.session['font_size'] = "12px"
    # store our data in dictionary to grab
    temp_list = {}
    temp_list["word"] = request.session['word']
    temp_list["color"] = request.session['color']
    temp_list["bigfonts"] = request.session['bigfonts'] 
    temp_list["time"] = strftime("%Y-%m-%d %H:%M %p", gmtime())
    print(temp_list)
    return redirect('/session_words')

def clear(request):
    del request.session['word']
    del request.session['color']
    del request.session['bigfonts']
    return redirect('/session_words')