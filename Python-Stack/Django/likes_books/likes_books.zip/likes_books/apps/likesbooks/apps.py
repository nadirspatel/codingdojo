from django.apps import AppConfig


class LikesbooksConfig(AppConfig):
    name = 'likesbooks'
