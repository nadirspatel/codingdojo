from django.apps import AppConfig


class BooksauthorsConfig(AppConfig):
    name = 'booksauthors'
