from django.apps import AppConfig


class MainAppConfig(AppConfig):
    name = 'main_app'
