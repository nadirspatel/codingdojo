from django.apps import AppConfig


class LoginRegConfig(AppConfig):
    name = 'loginreg'
